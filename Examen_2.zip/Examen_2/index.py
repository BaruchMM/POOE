import random as rn
import string
import numpy as np



clientes = {}
empleados = {}
ventas = {}


